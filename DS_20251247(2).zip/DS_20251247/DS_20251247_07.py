from tkinter import*

def print_rectangle():
    canvas.delete("all")
    canvas.create_rectangle(50,25,200,100,fill="red")

def print_oval():
    canvas.delete("all")
    canvas.create_oval(10,10,200,100,fill="blue")

def delete_all():
    canvas.delete("all")


root=Tk()

root.title("중간고사 7번")
root.geometry("420x440")

canvas = Canvas(root, width=400, height = 320)
canvas.pack()

frame=Frame(root, width=200, height=100)
frame.pack()

button1=Button(frame,text="사각형")
button1.pack(side="left", command=print_rectangle())

button2=Button(frame,text="원")
button2.pack(side="left", command=print_oval())

button3=Button(frame,text="그림")
button3.pack(side="left")

button4=Button(frame,text="지우기")
button4.pack(side="left"command=delete_all())

root.mainloop()




