class Inventory:
    
    def __init__(self,stock,amount):
        self.__stock=stock
        self.__amount=amount
        print("새 상품이 등록되었습니다.")


    def get_stock(self):
        return self.__stock

    def set_stock(self):
        if self.__amount<0:
            return 0
        else:
            return self.__amount

    def add_stock(self):
        if self.__amount<0:
            return False
        else:
            print(f"{self.__stock}개가 입고되었습니다.")
    
    def remove_stock(self):
        if self.__amount>self.__stock:
            return False
        else:
            return self.__stock-self.__amount

    

item1=Inventory()
item1.add_stock(10)
item1.remove_stock(3)
print("현재 재고 수량:",item1.get_stock())

item1.set_stock(20)
print("수정된 재고 수량:",item1.get_stock())